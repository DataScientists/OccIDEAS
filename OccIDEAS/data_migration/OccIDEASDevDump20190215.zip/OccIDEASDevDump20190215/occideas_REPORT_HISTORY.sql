-- MySQL dump 10.13  Distrib 5.7.25, for Linux (x86_64)
--
-- Host: localhost    Database: occideas
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `REPORT_HISTORY`
--

DROP TABLE IF EXISTS `REPORT_HISTORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REPORT_HISTORY` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(128) NOT NULL,
  `name` varchar(128) NOT NULL,
  `path` varchar(128) DEFAULT NULL,
  `status` varchar(128) NOT NULL,
  `progress` varchar(128) NOT NULL,
  `requestor` varchar(128) NOT NULL,
  `jsonData` longtext,
  `updatedDt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` varchar(128) DEFAULT NULL,
  `startDt` timestamp NULL DEFAULT NULL,
  `endDt` timestamp NULL DEFAULT NULL,
  `duration` float DEFAULT NULL,
  `recordCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REPORT_HISTORY`
--

LOCK TABLES `REPORT_HISTORY` WRITE;
/*!40000 ALTER TABLE `REPORT_HISTORY` DISABLE KEYS */;
INSERT INTO `REPORT_HISTORY` VALUES (13,'Lookup','12_test-Lookup.csv','/opt/data/reports/12_test.csv','Completed','100.0%','assessor',NULL,'2018-06-04 23:08:52',NULL,'2018-06-04 23:08:53','2018-06-04 23:08:53',2,0),(14,'Interview Fired Rules','FiredRules1.csv','/opt/data/reports/14_FiredRules1.csv','Completed','100.0%','assessor',NULL,'2018-07-20 04:23:50','assessor',NULL,NULL,0,0),(15,'Noise_Assessment (Export Noise Assessments)','NoiseCalcs.csv','/opt/data/reports/15_NoiseCalcs.csv','Completed','100.0%','assessor',NULL,'2018-07-20 04:24:22','assessor','2018-07-20 04:24:21','2018-07-20 04:24:22',0,31),(16,'Interviews (Export)','AllInterviews.csv','/opt/data/reports/16_AllInterviews.csv','Completed','100.0%','assessor',NULL,'2018-07-20 05:00:49','assessor','2018-07-20 05:00:49','2018-07-20 05:00:50',0,36),(17,'Lookup','16_AllInterviews-Lookup.csv','/opt/data/reports/16_AllInterviews.csv','Completed','100.0%','assessor',NULL,'2018-07-20 05:00:49',NULL,'2018-07-20 05:00:50','2018-07-20 05:00:50',2,0),(18,'Assessments (Export Assessments)','MECHINTR.csv','/opt/data/reports/18_MECHINTR.csv','Completed','100.0%','assessor',NULL,'2018-07-20 05:18:06','assessor','2018-07-20 05:18:06','2018-07-20 05:18:06',0,36),(19,'Notes (Export)','MECHINTR-Notes.csv','/opt/data/reports/19_MECHINTR-Notes.csv','Completed','100.0%','assessor',NULL,'2018-07-20 05:19:09','assessor','2018-07-20 05:19:08','2018-07-20 05:19:09',0,36),(20,'Noise_Assessment (Export Noise Assessments)','MECHINTR.csv','/opt/data/reports/20_MECHINTR.csv','Completed','100.0%','assessor',NULL,'2018-07-20 05:21:40','assessor','2018-07-20 05:21:39','2018-07-20 05:21:41',0,36),(24,'Noise_Assessment (Export Noise Assessments)','vibtest.csv','/opt/data/reports/24_vibtest.csv','Completed','100.0%','assessor',NULL,'2018-08-03 03:18:14','assessor','2018-08-03 03:18:13','2018-08-03 03:18:15',0,40),(25,'Noise_Assessment (Export Noise Assessments)','MECH.csv','/opt/data/reports/25_MECH.csv','In Progress','.2%','admin',NULL,'2018-08-04 11:35:57','admin','2018-08-04 11:35:57',NULL,0,35),(26,'Noise_Assessment (Export Noise Assessments)','MECHINTR.csv','/opt/data/reports/26_MECHINTR.csv','Completed','100.0%','assessor',NULL,'2018-08-22 07:33:00','assessor','2018-08-22 07:32:58','2018-08-22 07:33:00',0,41),(31,'Lookup','30_test interviews-Lookup.csv','/opt/data/reports/30_test interviews.csv','Completed','100.0%','assessor',NULL,'2018-09-05 13:41:14',NULL,'2018-09-05 13:41:15','2018-09-05 13:41:15',4,0),(34,'Noise_Assessment (Export Noise Assessments)','testvib.csv','/opt/data/reports/34_testvib.csv','Completed','100.0%','assessor',NULL,'2018-09-05 13:42:01','assessor','2018-09-05 13:42:00','2018-09-05 13:42:02',0,35);
/*!40000 ALTER TABLE `REPORT_HISTORY` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-15  9:48:30
