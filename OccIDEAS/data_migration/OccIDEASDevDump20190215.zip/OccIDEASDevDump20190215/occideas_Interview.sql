-- MySQL dump 10.13  Distrib 5.7.25, for Linux (x86_64)
--
-- Host: localhost    Database: occideas
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Interview`
--

DROP TABLE IF EXISTS `Interview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Interview` (
  `idinterview` bigint(20) NOT NULL AUTO_INCREMENT,
  `module_idNode` bigint(20) DEFAULT NULL,
  `fragment_idNode` bigint(20) DEFAULT NULL,
  `referenceNumber` varchar(255) NOT NULL,
  `idParticipant` bigint(20) NOT NULL,
  `parentId` bigint(20) DEFAULT NULL,
  `assessedStatus` varchar(255) DEFAULT '',
  PRIMARY KEY (`idinterview`),
  KEY `FK_srh0vgdnt8f7vvdmj88uxafsi` (`module_idNode`),
  CONSTRAINT `FK_srh0vgdnt8f7vvdmj88uxafsi` FOREIGN KEY (`module_idNode`) REFERENCES `Node` (`idNode`)
) ENGINE=InnoDB AUTO_INCREMENT=1134 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Interview`
--

LOCK TABLES `Interview` WRITE;
/*!40000 ALTER TABLE `Interview` DISABLE KEYS */;
INSERT INTO `Interview` VALUES (1092,NULL,NULL,'M9000001',475,0,'Auto Assessed'),(1093,NULL,NULL,'M9000002',476,0,'Auto Assessed'),(1094,NULL,NULL,'M9000003',477,0,'Auto Assessed'),(1095,NULL,NULL,'M9000004',478,0,'Auto Assessed'),(1096,NULL,NULL,'M9111111',479,0,'Auto Assessed'),(1097,NULL,NULL,'M9222222',480,0,'Auto Assessed'),(1098,NULL,NULL,'MT242342',481,0,'Auto Assessed'),(1099,NULL,NULL,'M9666666',482,0,'Auto Assessed'),(1100,NULL,NULL,'MT999000',483,0,'Manually assessed'),(1101,NULL,NULL,'Mt999911',484,0,'Auto Assessed'),(1102,NULL,NULL,'MT999912',485,0,'Auto Assessed'),(1103,NULL,NULL,'M9111111',486,0,'Auto Assessed'),(1104,NULL,NULL,'MT111111',487,0,'Auto Assessed'),(1105,NULL,NULL,'MT000000',488,0,'Auto Assessed'),(1106,NULL,NULL,'MT000001',489,0,'Auto Assessed'),(1107,NULL,NULL,'M9000005',490,0,'Auto Assessed'),(1108,NULL,NULL,'M9000007',491,0,'Auto Assessed'),(1109,NULL,NULL,'M0000003',492,0,'Auto Assessed'),(1110,NULL,NULL,'M0000001',493,0,'Auto Assessed'),(1111,NULL,NULL,'M0000007',494,0,'Auto Assessed'),(1112,NULL,NULL,'MS000001',495,0,'Auto Assessed'),(1113,NULL,NULL,'MS000001',496,0,'Auto Assessed'),(1114,NULL,NULL,'MS000003',497,0,'Manually assessed'),(1115,NULL,NULL,'MS000002',498,0,'Manually assessed'),(1116,NULL,NULL,'MS000004',499,0,'Manually assessed'),(1117,NULL,NULL,'MS000005',500,0,'Manually assessed'),(1118,NULL,NULL,'MS000008',501,0,'Manually assessed'),(1119,NULL,NULL,'MS000007',502,0,'Manually assessed'),(1120,NULL,NULL,'M0002406',503,0,'Auto Assessed'),(1121,NULL,NULL,'M0002406',504,0,'Auto Assessed'),(1122,NULL,NULL,'M0002406',505,0,'Auto Assessed'),(1123,NULL,NULL,'MS000006',506,0,'Manually assessed'),(1124,NULL,NULL,'MS000009',507,0,'Manually assessed'),(1125,NULL,NULL,'MS000010',508,0,'Manually assessed'),(1126,NULL,NULL,'MS000011',509,0,'Manually assessed'),(1127,NULL,NULL,'MS000012',510,0,'Manually assessed'),(1128,NULL,NULL,'MS000013',511,0,'Manually assessed'),(1129,NULL,NULL,'MS000014',512,0,'Needs Review'),(1130,NULL,NULL,'MS000015',513,0,'Auto Assessed'),(1131,NULL,NULL,'MS000016',514,0,'Finished'),(1132,NULL,NULL,'MS000015',515,0,'Not Assessed'),(1133,59970,NULL,'M0001111',516,0,'Not Assessed');
/*!40000 ALTER TABLE `Interview` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-15  9:45:37
