-- MySQL dump 10.13  Distrib 5.7.25, for Linux (x86_64)
--
-- Host: localhost    Database: occideas
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `SYS_CONFIG`
--

DROP TABLE IF EXISTS `SYS_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SYS_CONFIG` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(128) NOT NULL,
  `name` varchar(128) NOT NULL,
  `value` varchar(128) DEFAULT NULL,
  `updatedDt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYS_CONFIG`
--

LOCK TABLES `SYS_CONFIG` WRITE;
/*!40000 ALTER TABLE `SYS_CONFIG` DISABLE KEYS */;
INSERT INTO `SYS_CONFIG` VALUES (1,'config','activeIntro','59970','2017-11-08 03:56:17','contdev'),(3,'config','filterStudyAgent','true','2017-11-08 04:59:49',NULL),(4,'config','studyidprefix','M','2017-11-10 00:42:10',NULL),(5,'config','studyidlength','8','2017-11-10 00:43:17',NULL),(6,'config','REPORT_EXPORT_CSV_DIR','/opt/data/reports/','2018-03-14 02:38:43',NULL),(7,'studyagent','Styrene','77','2018-04-13 00:50:34','admin'),(8,'studyagent','Lead','51','2018-04-13 00:50:43','admin'),(9,'studyagent','Mercury','133','2018-04-13 00:50:46','admin'),(10,'studyagent','IMPACT NOISE','126','2018-04-13 00:50:54','admin'),(11,'studyagent','noise2','116','2018-04-13 00:50:55','admin'),(12,'studyagent','Noise tag','187','2018-04-13 00:51:01','admin'),(13,'studyagent','Carbon Monoxide','139','2018-04-13 00:51:15','admin'),(14,'studyagent','Ethyl Benzene','136','2018-04-13 00:51:26','admin'),(15,'studyagent','n-hexane','137','2018-04-13 00:51:28','admin'),(16,'studyagent','p-xylene','135','2018-04-13 00:51:31','admin'),(17,'studyagent','Toluene','134','2018-04-13 00:51:33','admin'),(18,'studyagent','Trichloroethylene','9','2018-04-13 00:51:36','admin'),(19,'NOISEAGENT','Noise2','116','2018-07-22 14:08:43',NULL),(20,'VIBRATIONAGENT','Vibration','157','2018-07-22 14:09:16',NULL);
/*!40000 ALTER TABLE `SYS_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-15  9:46:26
